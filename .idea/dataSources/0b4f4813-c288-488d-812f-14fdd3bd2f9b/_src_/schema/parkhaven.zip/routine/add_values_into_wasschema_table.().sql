CREATE PROCEDURE add_values_into_wasschema_table()
  BEGIN

	/*
	* Delete all rows from week 1.
    * Set all week_dag_tijd_id from week 2 to week 1
	* Insert new rows for week 2
	* (Inside week_dag_tijd table there are 13*7 = 91 values per week) 1 - 91 is week 1
	*/

	DECLARE current_id_week_1 SMALLINT(5) DEFAULT 1;
	DECLARE current_id_week_2 SMALLINT(5) DEFAULT 92;
    DECLARE wasmachine_id TINYINT(3) DEFAULT 1;

	DELETE FROM wasschema 
WHERE
    week_dag_tijd_id < 92;

	WHILE current_id_week_1 < 92
    DO
		UPDATE wasschema SET week_dag_tijd_id = current_id_week_1 WHERE week_dag_tijd_id = current_id_week_1 + 91;
        SET current_id_week_1 = current_id_week_1 + 1;
	END WHILE;

	WHILE wasmachine_id < 9
    DO
		WHILE current_id_week_2 < 183
        DO
			INSERT INTO wasschema (week_dag_tijd_id, wasmachine_id) VALUES (current_id_week_2, wasmachine_id);
            SET current_id_week_2 = current_id_week_2 + 1;
		END WHILE;
        SET current_id_week_2 = 92;
        SET wasmachine_id = wasmachine_id + 1;
	END WHILE;

END;
