CREATE PROCEDURE check_free_and_atleast_5min_prior(IN week_dag_tijd_id INT, IN wasmachine_id SMALLINT(3))
  BEGIN

DECLARE current_day_id TINYINT(3) DEFAULT DATE_FORMAT(CURDATE(), '%w'); -- Date 0 = Sunday, 6 = Saturday
DECLARE max_time_diff TIME DEFAULT '00:05'; -- 5 min

IF week_dag_tijd_id > 90 THEN -- IF Next Week
	SET current_day_id = -1;
END IF;

IF (SELECT 
			b.id 
		FROM 
			week_dag_tijd a
				LEFT JOIN
			dag b ON a.dag_id = b.id 
		WHERE
			a.id = week_dag_tijd_id) != current_day_id THEN -- Dag van Appointment != current_dag_id
	SET max_time_diff = '-24:00';
END IF;

IF current_day_id = 0 THEN
	SET current_day_id = 7; -- Set Sunday = 7
END IF;

SELECT 
    x.gebruiker_id
FROM
    wasschema x
        LEFT JOIN
    week_dag_tijd a ON x.week_dag_tijd_id = a.id
        LEFT JOIN
    tijd b ON a.tijd_id = b.id
        LEFT JOIN
    dag c ON a.dag_id = c.id
WHERE
    x.week_dag_tijd_id = week_dag_tijd_id
        AND x.wasmachine_id = wasmachine_id
        AND c.id >= current_day_id
		AND max_time_diff <= TIMEDIFF(b.tijd_default, CURTIME()); -- 00:05 < Current Time + Time of Appointment 

END;
